<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>PHP + MySQL 的 Web 伺服器</title>
</head>
<body>
<h3>Web伺服器的網址: </h3>
<p><b><span style="color:red;"> http://localhost:8080/[目錄]/[檔名]</span></b></p>
<?php phpinfo();?>
</body>
</html>